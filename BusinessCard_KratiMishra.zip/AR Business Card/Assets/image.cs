using UnityEngine;
using Vuforia;

public class ShowObjectsOnTracking : MonoBehaviour
{
    public GameObject qrCode;
    public GameObject videoPlayer;
    
    private ObserverBehaviour observerBehaviour;

    void Start()
    {
        // Get the ObserverBehaviour component and listen for tracking changes
        observerBehaviour = GetComponent<ObserverBehaviour>();
        
        if (observerBehaviour != null)
        {
            observerBehaviour.OnTargetStatusChanged += OnTrackingStatusChanged;
        }

        // Initially hide objects
        qrCode.SetActive(false);
        videoPlayer.SetActive(false);
    }

    private void OnTrackingStatusChanged(ObserverBehaviour behaviour, TargetStatus targetStatus)
    {
        if (targetStatus.Status == Status.TRACKED)
        {
            qrCode.SetActive(true);
            videoPlayer.SetActive(true);
        }
        else
        {
            qrCode.SetActive(false);
            videoPlayer.SetActive(false);
        }
    }
}

