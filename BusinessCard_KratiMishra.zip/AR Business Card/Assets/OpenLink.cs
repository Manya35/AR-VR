using UnityEngine;

public class OpenLink : MonoBehaviour
{
    public string url = "https://yourwebsite.com";

    public void OpenWebsite()
    {
        Application.OpenURL(url);
    }
}

