using UnityEngine;
using Vuforia;

public class CardInteraction : MonoBehaviour
{
    private ObserverBehaviour observerBehaviour;
    public GameObject cube;      // Assign the Cube in Inspector
    public GameObject qrCode;    // Assign the QR Code in Inspector
    public GameObject infoText;  // Assign the Text in Inspector

    private bool isInfoVisible = false; // Initially hidden

    void Start()
    {
        observerBehaviour = GetComponent<ObserverBehaviour>();

        if (observerBehaviour)
        {
            observerBehaviour.OnTargetStatusChanged += OnTargetStatusChanged;
        }

        // Initially hide everything
        HideAll();
    }

    private void OnTargetStatusChanged(ObserverBehaviour behaviour, TargetStatus status)
    {
        if (status.Status == Status.TRACKED || status.Status == Status.EXTENDED_TRACKED)
        {
            ShowCubeOnly();
        }
        else
        {
            HideAll();
        }
    }

    void ShowCubeOnly()
    {
        if (cube != null)
        {
            cube.SetActive(true);
            cube.transform.localPosition = new Vector3(0, 0.05f, 0); // Move cube above target
        }

        if (qrCode != null) qrCode.SetActive(false);
        if (infoText != null) infoText.SetActive(false);
    }

    void HideAll()
    {
        if (cube != null) cube.SetActive(false);
        if (qrCode != null) qrCode.SetActive(false);
        if (infoText != null) infoText.SetActive(false);
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0)) // Detect click/tap
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                if (hit.collider.gameObject == cube) // If cube is clicked
                {
                    ToggleInfo();
                }
            }
        }
    }

    void ToggleInfo()
    {
        isInfoVisible = !isInfoVisible; // Toggle visibility
        if (qrCode != null) qrCode.SetActive(isInfoVisible);
        if (infoText != null) infoText.SetActive(isInfoVisible);
    }
}







