﻿public class HumanPlayer : Player
{
}